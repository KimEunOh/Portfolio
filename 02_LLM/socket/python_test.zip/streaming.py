from fastapi import (
    FastAPI,
    WebSocket,
    WebSocketDisconnect,
    Request,
    Form,
    Depends,
    HTTPException,
)
from fastapi.responses import HTMLResponse, JSONResponse
from fastapi.templating import Jinja2Templates
from typing import Dict, List
import json
from datetime import datetime, timedelta
import uuid
from pydantic import BaseModel
from fastapi.staticfiles import StaticFiles
from sqlalchemy.orm import Session
from models import (
    User,
    Message,
    RoomStats,
    DailyStats,
    get_db,
    init_db,
    DB_FILE,
    update_room_stats,
    update_daily_stats,
    SystemMetrics,
    update_system_metrics,
    get_system_metrics,
)
import hashlib
import os
from sqlalchemy import func
import psutil
import time

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")


# 애플리케이션 시작 시 데이터베이스 확인
@app.on_event("startup")
async def startup_event():
    # 데이터베이스 파일이 없을 때만 초기화
    if not os.path.exists(DB_FILE):
        print("데이터베이스 파일이 없습니다. 초기화를 시작합니다...")
        init_db()
    else:
        print("기존 데이터베이스를 사용합니다.")


# 채팅방 정보
CHAT_ROOMS = {
    "room1": "일반 채팅방",
    "room2": "게임 채팅방",
    "room3": "음악 채팅방",
    "room4": "영화 채팅방",
}


# 데이터 모델
class UserInfo(BaseModel):
    id: str
    nickname: str
    is_admin: bool = False
    created_at: datetime = datetime.now()
    current_room: str = "room1"


class ChatMessage(BaseModel):
    user_id: str
    content: str
    type: str
    room_id: str
    timestamp: datetime = datetime.now()


# 연결 관리자
class ConnectionManager:
    def __init__(self):
        self.active_connections: Dict[str, Dict[str, WebSocket]] = {
            room_id: {} for room_id in CHAT_ROOMS.keys()
        }
        self.user_info: Dict[str, UserInfo] = {}
        self.room_participants: Dict[str, int] = {
            room_id: 0 for room_id in CHAT_ROOMS.keys()
        }
        self.admin_messages: Dict[str, List[ChatMessage]] = {
            room_id: [] for room_id in CHAT_ROOMS.keys()
        }
        self.user_current_room: Dict[str, str] = {}
        self.message_timestamps = {}
        self.error_counts = {room_id: 0 for room_id in CHAT_ROOMS.keys()}
        self.start_time = time.time()
        self.message_counts = {room_id: 0 for room_id in CHAT_ROOMS.keys()}
        self.last_message_time = {room_id: time.time() for room_id in CHAT_ROOMS.keys()}

    async def collect_metrics(self, room_id: str, db: Session):
        """시스템 성능 지표 수집"""
        current_time = time.time()

        # 초당 메시지 수 계산 (최근 1초 동안)
        elapsed_since_last = current_time - self.last_message_time[room_id]
        if elapsed_since_last > 0:
            messages_per_second = (
                self.message_counts[room_id] / elapsed_since_last
                if self.message_counts[room_id] > 0
                else 0
            )
        else:
            messages_per_second = 0

        # 시스템 리소스 사용량
        process = psutil.Process()
        cpu_usage = psutil.cpu_percent(interval=0.1)
        memory_usage = process.memory_info().rss / 1024 / 1024  # MB 단위

        metrics = {
            "active_connections": len(self.active_connections[room_id]),
            "connection_errors": self.error_counts[room_id],
            "avg_latency": 0.0,  # 실제 구현시 WebSocket 지연시간 측정 필요
            "messages_per_second": messages_per_second,
            "message_queue_size": len(self.active_connections[room_id]),
            "failed_messages": 0,
            "cpu_usage": cpu_usage,
            "memory_usage": memory_usage,
            "error_count": self.error_counts[room_id],
            "error_types": "{}",
        }

        # 메시지 카운터 초기화
        self.message_counts[room_id] = 0
        self.last_message_time[room_id] = current_time

        update_system_metrics(db, room_id, metrics)
        return metrics

    async def cleanup_previous_connection(self, user_id: str):
        """이전 연결을 정리하는 함수"""
        previous_room = self.user_current_room.get(user_id)
        if previous_room:
            if user_id in self.active_connections[previous_room]:
                try:
                    old_connection = self.active_connections[previous_room][user_id]
                    del self.active_connections[previous_room][user_id]
                    self.room_participants[previous_room] = max(
                        0, self.room_participants[previous_room] - 1
                    )
                    try:
                        await old_connection.close()
                    except Exception:
                        pass  # 이미 닫힌 연결에 대한 오류 무시
                except Exception as e:
                    print(f"이전 연결 정리 중 오류 발생: {e}")

    async def connect(self, websocket: WebSocket, user_id: str, room_id: str):
        try:
            await websocket.accept()
            print(f"사용자 {user_id} 연결 시도 - 채팅방: {room_id}")

            # 이전 연결 정리
            await self.cleanup_previous_connection(user_id)

            # 새로운 연결 설정
            self.active_connections[room_id][user_id] = websocket
            self.user_current_room[user_id] = room_id
            if user_id in self.user_info:
                self.user_info[user_id].current_room = room_id
            self.room_participants[room_id] += 1

            print(
                f"사용자 {user_id} 연결 완료 - 채팅방: {room_id}, 참가자 수: {self.room_participants[room_id]}"
            )
            await self.broadcast_room_status_to_all()

            # 관리자 메시지 히스토리 전송
            await self.send_admin_history(websocket, room_id)

            self.message_timestamps[room_id] = time.time()
        except Exception as e:
            print(f"WebSocket 연결 중 오류 발생: {e}")
            self.error_counts[room_id] += 1
            raise

    async def send_admin_history(self, websocket: WebSocket, room_id: str):
        """관리자 메시지 히스토리를 전송하는 함수"""
        if room_id in self.admin_messages and self.admin_messages[room_id]:
            messages = []
            for msg in self.admin_messages[room_id][-5:]:
                if msg.user_id in self.user_info:
                    messages.append(
                        {
                            "user_id": msg.user_id,
                            "nickname": self.user_info[msg.user_id].nickname,
                            "content": msg.content,
                            "timestamp": msg.timestamp.isoformat(),
                            "type": "admin",
                        }
                    )

            if messages:
                try:
                    await websocket.send_json(
                        {"type": "admin_history", "messages": messages}
                    )
                except Exception as e:
                    print(f"Error sending admin history: {e}")

    def disconnect(self, user_id: str, room_id: str):
        try:
            if (
                room_id in self.active_connections
                and user_id in self.active_connections[room_id]
            ):
                del self.active_connections[room_id][user_id]
                self.room_participants[room_id] = max(
                    0, self.room_participants[room_id] - 1
                )
                if (
                    user_id in self.user_current_room
                    and self.user_current_room[user_id] == room_id
                ):
                    del self.user_current_room[user_id]
                print(
                    f"사용자 {user_id} 연결 해제 - 채팅방: {room_id}, 참가자 수: {self.room_participants[room_id]}"
                )
        except Exception as e:
            print(f"연결 해제 중 오류 발생: {e}")
            self.error_counts[room_id] += 1

    async def broadcast(self, message: dict, room_id: str):
        try:
            if room_id in self.active_connections:
                # 딕셔너리의 복사본을 만들어 순회
                connections = list(self.active_connections[room_id].items())
                for user_id, connection in connections:
                    try:
                        await connection.send_json(message)
                    except Exception as e:
                        print(
                            f"Error broadcasting message to user {user_id}: {e}"
                        )  # 디버깅용
                        # 연결이 끊어진 경우 해당 연결 제거
                        if user_id in self.active_connections[room_id]:
                            del self.active_connections[room_id][user_id]
                            self.room_participants[room_id] = max(
                                0, self.room_participants[room_id] - 1
                            )

            self.message_counts[room_id] += 1
            self.last_message_time[room_id] = time.time()
        except Exception as e:
            self.error_counts[room_id] += 1
            raise e

    async def broadcast_room_status_to_all(self):
        status_message = {
            "type": "room_status",
            "rooms": {
                room_id: self.room_participants[room_id]
                for room_id in CHAT_ROOMS.keys()
            },
        }
        for room_id in CHAT_ROOMS.keys():
            await self.broadcast(status_message, room_id)

    def register_user(self, user_id: str, nickname: str, is_admin: bool = False):
        self.user_info[user_id] = UserInfo(
            id=user_id, nickname=nickname, is_admin=is_admin
        )

    def get_room_participants(self, room_id: str) -> int:
        return self.room_participants.get(room_id, 0)

    def add_admin_message(self, message: ChatMessage):
        if message.room_id in self.admin_messages:
            self.admin_messages[message.room_id].append(message)
            # 최대 100개의 메시지만 유지
            if len(self.admin_messages[message.room_id]) > 100:
                self.admin_messages[message.room_id] = self.admin_messages[
                    message.room_id
                ][-100:]
            print(
                f"Admin message added to room {message.room_id}: {message.content}"
            )  # 디버깅용

    async def broadcast_admin_message(self, message: ChatMessage, room_id: str):
        """관리자 메시지를 브로드캐스트하고 요약 정보도 함께 전송"""
        if message.room_id in self.admin_messages and message.user_id in self.user_info:
            # 메시지 저장
            self.add_admin_message(message)

            # 브로드캐스트할 메시지 생성
            broadcast_message = {
                "user_id": message.user_id,
                "nickname": self.user_info[message.user_id].nickname,
                "content": message.content,
                "type": "admin",
                "room_id": room_id,
                "timestamp": message.timestamp.isoformat(),
            }

            # 메시지 브로드캐스트
            await self.broadcast(broadcast_message, room_id)

            # 요약 정보 업데이트
            summary_message = {"type": "admin_summary", "message": broadcast_message}
            await self.broadcast(summary_message, room_id)
        else:
            print(
                f"Warning: Cannot broadcast admin message - User {message.user_id} not found or invalid room"
            )  # 디버깅용


manager = ConnectionManager()


# 라우트 핸들러
@app.get("/streaming", response_class=HTMLResponse)
async def get_chat_page(request: Request):
    room_status = {
        room_id: manager.get_room_participants(room_id) for room_id in CHAT_ROOMS.keys()
    }
    return templates.TemplateResponse(
        "streaming.html",
        {"request": request, "chat_rooms": CHAT_ROOMS, "room_status": room_status},
    )


# 비밀번호 해싱 함수
def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


# 사용자 인증 함수
def authenticate_user(db: Session, username: str, password: str) -> User:
    user = db.query(User).filter(User.username == username).first()
    if not user:
        print(f"User not found: {username}")  # 디버깅 로그
        raise HTTPException(status_code=401, detail="잘못된 사용자명 또는 비밀번호")

    hashed_password = hash_password(password)
    print(
        f"Login attempt - Username: {username}, Hashed password: {hashed_password}"
    )  # 디버깅 로그
    print(f"Stored password: {user.password}")  # 디버깅 로그

    if user.password != hashed_password:
        print(f"Password mismatch for user: {username}")  # 디버깅 로그
        raise HTTPException(status_code=401, detail="잘못된 사용자명 또는 비밀번호")

    return user


@app.post("/user/register")
async def register_user(
    nickname: str = Form(...),
    username: str = Form(...),
    password: str = Form(...),
    db: Session = Depends(get_db),
):
    try:
        print(f"회원가입 시도 - 닉네임: {nickname}, 사용자명: {username}")  # 디버깅용

        # 사용자명 중복 확인
        existing_user = db.query(User).filter(User.username == username).first()
        if existing_user:
            print(f"사용자명 중복: {username}")  # 디버깅용
            raise HTTPException(status_code=400, detail="이미 사용 중인 사용자명입니다")

        user_id = str(uuid.uuid4())
        hashed_password = hash_password(password)

        print(f"새 사용자 생성 - ID: {user_id}")  # 디버깅용

        # 데이터베이스에 사용자 저장
        db_user = User(
            id=user_id,
            nickname=nickname,
            username=username,
            password=hashed_password,
            is_admin=False,  # 일반 사용자는 관리자가 아님
        )
        db.add(db_user)
        db.commit()

        print(f"사용자 저장 완료 - ID: {user_id}")  # 디버깅용

        # 저장된 사용자 확인
        saved_user = db.query(User).filter(User.id == user_id).first()
        if not saved_user:
            print(
                f"오류: 사용자가 데이터베이스에 저장되지 않음 - ID: {user_id}"
            )  # 디버깅용
            raise HTTPException(
                status_code=500, detail="사용자 저장 중 오류가 발생했습니다"
            )

        manager.register_user(user_id, nickname, is_admin=False)

        return {"user_id": user_id, "nickname": nickname, "is_admin": False}
    except HTTPException as e:
        print(f"회원가입 실패: {str(e)}")  # 디버깅용
        raise e
    except Exception as e:
        print(f"회원가입 중 예외 발생: {str(e)}")  # 디버깅용
        raise HTTPException(status_code=500, detail="회원가입 중 오류가 발생했습니다")


@app.post("/user/login")
async def login_user(
    username: str = Form(...), password: str = Form(...), db: Session = Depends(get_db)
):
    try:
        print(f"Login attempt for username: {username}")  # 디버깅 로그

        # 사용자 인증
        user = authenticate_user(db, username, password)

        # 관리자 여부 확인 (데이터베이스에서 직접 확인)
        is_admin = db.query(User).filter(User.id == user.id).first().is_admin

        print(
            f"User authenticated - ID: {user.id}, Nickname: {user.nickname}, Is Admin: {is_admin}"
        )  # 디버깅 로그

        # ConnectionManager에 사용자 정보 등록
        manager.register_user(user.id, user.nickname, is_admin=is_admin)

        return {"user_id": user.id, "nickname": user.nickname, "is_admin": is_admin}
    except HTTPException as e:
        print(f"Login failed: {str(e)}")  # 디버깅 로그
        raise e


@app.get("/stats/room/{room_id}")
async def get_room_stats(room_id: str, db: Session = Depends(get_db)):
    """채팅방 통계 조회"""
    # 일일 통계
    today = datetime.now().date()
    daily_stats = (
        db.query(DailyStats)
        .filter(func.date(DailyStats.date) == today, DailyStats.room_id == room_id)
        .first()
    )

    # 전체 사용자 통계
    room_user_stats = db.query(RoomStats).filter(RoomStats.room_id == room_id).all()

    # 활성 사용자 수 (최근 10분 이내 활동)
    recent_time = datetime.now() - timedelta(minutes=10)
    active_users = (
        db.query(RoomStats)
        .filter(RoomStats.room_id == room_id, RoomStats.last_active >= recent_time)
        .count()
    )

    return {
        "room_id": room_id,
        "today_stats": {
            "total_messages": daily_stats.total_messages if daily_stats else 0,
            "admin_messages": daily_stats.admin_messages if daily_stats else 0,
            "unique_users": daily_stats.unique_users if daily_stats else 0,
            "peak_users": daily_stats.peak_users if daily_stats else 0,
            "time_distribution": (
                json.loads(daily_stats.active_time_distribution) if daily_stats else {}
            ),
        },
        "total_stats": {
            "total_users": len(room_user_stats),
            "total_joins": sum(stat.join_count for stat in room_user_stats),
            "total_messages": sum(stat.message_count for stat in room_user_stats),
            "active_users": active_users,
        },
    }


@app.get("/stats/user/{user_id}")
async def get_user_stats(user_id: str, db: Session = Depends(get_db)):
    """사용자 통계 조회"""
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(status_code=404, detail="사용자를 찾을 수 없습니다")

    user_stats = db.query(RoomStats).filter(RoomStats.user_id == user_id).all()

    return {
        "user_id": user_id,
        "nickname": user.nickname,
        "is_admin": user.is_admin,
        "room_stats": [
            {
                "room_id": stat.room_id,
                "join_count": stat.join_count,
                "message_count": stat.message_count,
                "total_time": stat.total_time,
                "last_active": (
                    stat.last_active.isoformat() if stat.last_active else None
                ),
            }
            for stat in user_stats
        ],
    }


@app.websocket("/ws/chat/{user_id}/{room_id}")
async def websocket_endpoint(
    websocket: WebSocket, user_id: str, room_id: str, db: Session = Depends(get_db)
):
    if room_id not in CHAT_ROOMS:
        await websocket.close(code=4000, reason="Invalid room")
        return

    await manager.connect(websocket, user_id, room_id)

    # 입장 통계 업데이트
    update_room_stats(db, user_id, room_id, "join")

    # 성능 모니터링 작업 시작
    monitoring_interval = 60  # 60초마다 성능 지표 수집
    last_metrics_time = time.time()

    try:
        while True:
            # 성능 지표 주기적 수집
            current_time = time.time()
            if current_time - last_metrics_time >= monitoring_interval:
                await manager.collect_metrics(room_id, db)
                last_metrics_time = current_time

            data = await websocket.receive_text()
            message_data = json.loads(data)
            print(f"Received WebSocket message: {message_data}")

            if message_data.get("type") == "user_info":
                if user_id in manager.user_info:
                    is_admin = message_data.get("isAdmin", False)
                    manager.user_info[user_id].is_admin = is_admin
                continue

            user_info = manager.user_info.get(user_id)
            if not user_info:
                continue

            current_time = datetime.now()
            chat_message = ChatMessage(
                user_id=user_id,
                content=message_data["content"],
                type="admin" if user_info.is_admin else "user",
                room_id=room_id,
                timestamp=current_time,
            )

            # 메시지 통계 업데이트
            update_room_stats(db, user_id, room_id, "message")
            update_daily_stats(db, room_id, chat_message.type)

            if user_info.is_admin:
                manager.add_admin_message(chat_message)

            # 데이터베이스에 메시지 저장
            db_message = Message(
                user_id=user_id,
                content=chat_message.content,
                room_id=room_id,
                type=chat_message.type,
                timestamp=current_time,
            )
            db.add(db_message)
            db.commit()

            broadcast_message = {
                "user_id": user_id,
                "nickname": user_info.nickname,
                "content": chat_message.content,
                "type": chat_message.type,
                "room_id": room_id,
                "timestamp": current_time.isoformat(),
            }
            await manager.broadcast(broadcast_message, room_id)

    except WebSocketDisconnect:
        user_info = manager.user_info.get(user_id)
        nickname = user_info.nickname if user_info else "알 수 없는 사용자"
        manager.disconnect(user_id, room_id)

        # 퇴장 메시지 및 통계 업데이트
        current_time = datetime.now()
        db_message = Message(
            user_id=user_id,
            content=f"{nickname}님이 퇴장하셨습니다.",
            room_id=room_id,
            type="system",
            timestamp=current_time,
        )
        db.add(db_message)
        db.commit()

        await manager.broadcast(
            {
                "type": "system",
                "content": f"{nickname}님이 퇴장하셨습니다.",
                "timestamp": current_time.isoformat(),
            },
            room_id,
        )
        await manager.broadcast_room_status_to_all()
        manager.error_counts[room_id] += 1
    except Exception as e:
        manager.error_counts[room_id] += 1
        raise e


@app.get("/admin/stats", response_class=HTMLResponse)
async def get_admin_stats_page(request: Request):
    """관리자 통계 페이지"""
    return templates.TemplateResponse(
        "admin_stats.html", {"request": request, "chat_rooms": CHAT_ROOMS}
    )


@app.get("/stats/metrics/{room_id}")
async def get_system_metrics_api(room_id: str, db: Session = Depends(get_db)):
    """시스템 성능 메트릭 조회 API"""
    # 최근 메트릭 데이터 조회
    metrics = get_system_metrics(db, room_id, duration_minutes=1)

    # 현재 실시간 메트릭 수집
    current_metrics = await manager.collect_metrics(room_id, db)

    if not metrics:
        metrics = []

    # 시계열 데이터 구성
    timestamps = [m.timestamp.isoformat() for m in metrics]
    cpu_usage = [m.cpu_usage for m in metrics]
    memory_usage = [m.memory_usage for m in metrics]
    messages_per_second = [m.messages_per_second for m in metrics]

    return {
        "timestamps": timestamps,
        "cpu_usage": cpu_usage,
        "memory_usage": memory_usage,
        "messages_per_second": messages_per_second,
        "current": current_metrics,
    }


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)
